import setuptools
import subprocess

import subprocess

try:
    version = (
        subprocess.check_output(["git", "describe", "--abbrev=0", "--tags"], stderr=subprocess.DEVNULL)
        .strip()
        .decode("utf-8")
    )
except subprocess.CalledProcessError:
    try:
        from importlib.metadata import version as get_version
        version = get_version("sourcelocalizer")
    except:
        version = "0.0.1"  # Default fallback version

__version__ = version

setuptools.setup(
    name="sourcelocalizer",
    version=version,
    author="Hamza Abdelhedi",
    description="Localizing brain ROI of a source",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)